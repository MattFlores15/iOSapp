//
//  TabViewContent.swift
//  PoC
//
//  Created by Matias Flores on 29/10/2022.
//

import SwiftUI

struct TabViewContent: View {
    
    
    
    var body: some View {
        
        
       
        TabView{
            
            Group{
                HomeView( guide: GuideDataObject.mock()).tabItem{
                    Label("Home", systemImage: "house")
                }.accentColor(/*@START_MENU_TOKEN@*/Color("AccentColor")/*@END_MENU_TOKEN@*/)
                DiscoverView(guide: GuideDataObject.mock()).tabItem{
                    Label("Discover", systemImage: "safari")
                }.accentColor(/*@START_MENU_TOKEN@*/Color("AccentColor")/*@END_MENU_TOKEN@*/)
                
                SearchView().tabItem{
                    Label("Search", systemImage: "magnifyingglass")
                }.accentColor(/*@START_MENU_TOKEN@*/Color("AccentColor")/*@END_MENU_TOKEN@*/)
                
                SearchView().badge("!").tabItem{
                    Label("Profile", systemImage: "person.crop.square.fill")
                }.accentColor(/*@START_MENU_TOKEN@*/Color("AccentColor")/*@END_MENU_TOKEN@*/)
                
            }.toolbar(.visible, for: .tabBar)
            
                .toolbarBackground(Color("Menu"), for: .tabBar)
    
        }.navigationBarBackButtonHidden(true).navigationViewStyle(.columns).accentColor(Color("ToolB"))
    }
}

struct TabViewContent_Previews: PreviewProvider {
    static var previews: some View {
        TabViewContent()
    }
}
