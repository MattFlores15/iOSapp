import UIKit

class ProfileVC: UIViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
